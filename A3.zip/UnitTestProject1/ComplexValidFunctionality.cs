﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Frontend2;
using Frontend2.Hardware;

namespace UnitTestProject1
{
    [TestClass]
    public class ComplexValidFunctionality
    {
        [TestMethod]
        public void Test_ChangingConfiguration()
        {
        }
    }
}
