﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Frontend2;
using Frontend2.Hardware;

namespace UnitTestProject1
{
    [TestClass]
    public class BasicValidFunctionality
    {
        //Instantiate Variables To Be Used Across All Tests In This Test Case
        VendingMachineFactory VMF;
        Checker checker;
        List<IDeliverable> delivered;
        List<IDeliverable> expected;
        List<IDeliverable> unaccountedForDelivery;
        VendingMachineStoredContents storedContents;
        VendingMachineStoredContents expectedContents;
        VendingMachineStoredContents unaccountedForUnload;
        Coin five;
        Coin ten;
        Coin two5;
        Coin hund;
        PopCan coke;
        PopCan water;
        PopCan stuff;



        /*//////////////////////////////////////////////////////
         * Initialize
         * 
         * Initialize variables to be used across all tests
         *    in this test case    
         *//////////////////////////////////////////////////////
        [TestInitialize]
        public void Initialize()
        {
            VMF = new VendingMachineFactory();
            checker = new Checker();
            delivered = new List<IDeliverable>();
            expected = new List<IDeliverable>();
            unaccountedForDelivery = new List<IDeliverable>();
            storedContents = new VendingMachineStoredContents();
            expectedContents = new VendingMachineStoredContents();
            unaccountedForUnload = new VendingMachineStoredContents();
            five = new Coin(5);
            ten = new Coin(10);
            two5 = new Coin(25);
            hund = new Coin(100);
            coke = new PopCan("Coke");
            water = new PopCan("water");
            stuff = new PopCan("stuff");
        }








        /*//////////////////////////////////////////////////////
         * Test_PopDelivered_NoChangeDue
         *    Mimics : T01-good-insert-and-press-exact-change
         * 
         * Tests the scenario where;
         *    The amount entered is equal to the cost of the pop.
         *    No change is made or dispensed.
         *    All coins made as payment are sent to the coin racks. 
         *///////////////////////////////////////////////////////
        [TestMethod]
        public void Test_PopDelivered_NoChangeDue()
        {
            int[] coins = new int[4] { 5, 10, 25, 100 };
            List<int> coinKinds = new List<int>(coins);

            int[] costs = new int[3] { 250, 250, 205 };
            List<int> popCosts = new List<int>(costs);

            string[] names = new string[3] { "Coke", "water", "stuff" };
            List<string> popNames = new List<string>(names);

            Coin[] coinArr0 = new Coin[1] { five };
            Coin[] coinArr1 = new Coin[1] { ten };
            Coin[] coinArr2 = new Coin[2] { two5, two5 };
            Coin[] coinArr3 = new Coin[0];
            List<Coin> coinLoad0 = new List<Coin>(coinArr0);
            List<Coin> coinLoad1 = new List<Coin>(coinArr1);
            List<Coin> coinLoad2 = new List<Coin>(coinArr2);
            List<Coin> coinLoad3 = new List<Coin>(coinArr3);

            PopCan[] popArr0 = new PopCan[1] { coke };
            PopCan[] popArr1 = new PopCan[1] { water };
            PopCan[] popArr2 = new PopCan[1] { stuff };
            List<PopCan> popLoad0 = new List<PopCan>(popArr0);
            List<PopCan> popLoad1 = new List<PopCan>(popArr1);
            List<PopCan> popLoad2 = new List<PopCan>(popArr2);

            Coin[] coinArr4 = new Coin[2] { hund, hund };


            //Mimic Test Script Calls
            VMF.CreateVendingMachine(coinKinds, 3, 10, 10, 10);
            VMF.ConfigureVendingMachine(0, popNames, popCosts);
            VMF.LoadCoins(0, 0, coinLoad0);
            VMF.LoadCoins(0, 1, coinLoad1);
            VMF.LoadCoins(0, 2, coinLoad2);
            VMF.LoadCoins(0, 3, coinLoad3);
            VMF.LoadPops(0, 0, popLoad0);
            VMF.LoadPops(0, 1, popLoad1);
            VMF.LoadPops(0, 2, popLoad2);
            VMF.InsertCoin(0, hund);
            VMF.InsertCoin(0, hund);
            VMF.InsertCoin(0, two5);
            VMF.InsertCoin(0, two5);
            VMF.PressButton(0, 0);

            //Get Actual Delivery and set Expected Delivery
            delivered = VMF.ExtractFromDeliveryChute(0);
            expected.Add(coke);

            //Compare Actual Delivery to Exepected Delivery
            foreach (var item in expected)
            {
                Assert.IsTrue(delivered.Contains(item));
                delivered.Remove(item);
            }

            Assert.IsTrue(delivered.Count == 0);





            //Get Actual Unload and set Expected Unload
            storedContents = VMF.UnloadVendingMachine(0);
            expectedContents.CoinsInCoinRacks.Add(coinLoad0);
            expectedContents.CoinsInCoinRacks.Add(coinLoad1);
            expectedContents.CoinsInCoinRacks.Add(coinLoad2);
            expectedContents.CoinsInCoinRacks.Add(coinLoad3);
            expectedContents.CoinsInCoinRacks.Add(new List<Coin>(coinArr2));
            expectedContents.CoinsInCoinRacks.Add(new List<Coin>(coinArr4));
            expectedContents.PopCansInPopCanRacks.Add(new List<PopCan>(popArr1));
            expectedContents.PopCansInPopCanRacks.Add(new List<PopCan>(popArr2));



            //Compare Unload with Expected Unload -- See Function Documentation For "checkUnload" in Checker.cs
            unaccountedForUnload = checker.checkUnload(expectedContents, storedContents);
            foreach (var coinList in unaccountedForUnload.CoinsInCoinRacks)
                Assert.IsTrue(coinList.Count == 0);

            foreach (var popList in unaccountedForUnload.PopCansInPopCanRacks)
                Assert.IsTrue(popList.Count == 0);

            Assert.IsTrue(unaccountedForUnload.PaymentCoinsInStorageBin.Count == 0);


        }










        /*//////////////////////////////////////////////////////
        * Test_PopDelivered_ChangeDueIsAvailable
        *    Mimicks : T01-good-insert-and-press-exact-change
        * 
        * Tests the scenario where;
        *    The amount entered is greater than the cost of the pop.
        *    All change is made and dispensed.
        *    All coins made as payment are sent to the coin racks. 
        *///////////////////////////////////////////////////////
        [TestMethod]
        public void Test_PopDelivered_ChangeDueIsAvailable()
        {
            int[] coins = new int[4] { 5, 10, 25, 100 };
            List<int> coinKinds = new List<int>(coins);

            int[] costs = new int[3] { 250, 250, 205 };
            List<int> popCosts = new List<int>(costs);

            string[] names = new string[3] { "Coke", "water", "stuff" };
            List<string> popNames = new List<string>(names);

            Coin[] coinArr0 = new Coin[1] { five };
            Coin[] coinArr1 = new Coin[1] { ten };
            Coin[] coinArr2 = new Coin[2] { two5, two5 };
            Coin[] coinArr3 = new Coin[0];
            List<Coin> coinLoad0 = new List<Coin>(coinArr0);
            List<Coin> coinLoad1 = new List<Coin>(coinArr1);
            List<Coin> coinLoad2 = new List<Coin>(coinArr2);
            List<Coin> coinLoad3 = new List<Coin>(coinArr3);

            PopCan[] popArr0 = new PopCan[1] { coke };
            PopCan[] popArr1 = new PopCan[1] { water };
            PopCan[] popArr2 = new PopCan[1] { stuff };
            List<PopCan> popLoad0 = new List<PopCan>(popArr0);
            List<PopCan> popLoad1 = new List<PopCan>(popArr1);
            List<PopCan> popLoad2 = new List<PopCan>(popArr2);




            ////To be implemented

        }



        //////////etc..






    }
}
