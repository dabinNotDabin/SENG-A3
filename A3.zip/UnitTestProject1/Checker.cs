﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Frontend2;
using Frontend2.Hardware;

namespace UnitTestProject1
{
    public class Checker
    {

        public Checker() { }


        /*///////////////////////////////
       // Name    : checkUnload
       // Purpose : Compare two objects against one another for equality.
       // 
       // Inputs  :
       //     expected  -- VendingMachineStoredContents representing the expected return from a vending machine unload
       //     delivered -- VendingMachineStoredContents representing the actual contents returned by a vending machine unload
       // 
       // Return  :
       //     remaining -- VendingMachineStoredContents
       //                  - set equal to expected unload, items that match in actual delivery are removed one by one
       //                  - returns an empty list if expected is identical to delivery
       //
       //      
       *////////////////////////////////

        public VendingMachineStoredContents checkUnload(VendingMachineStoredContents expected, VendingMachineStoredContents delivered)
        {
            VendingMachineStoredContents remaining = expected;
            List<List<Coin>> coinsInRacks = delivered.CoinsInCoinRacks;
            List<List<PopCan>> popsInRacks = delivered.PopCansInPopCanRacks;
            List<Coin> coinsInStorage = delivered.PaymentCoinsInStorageBin;

            foreach (var list in coinsInRacks)
                foreach (var item in list)
                {
                    foreach (var coinList in remaining.CoinsInCoinRacks)
                        if (coinList.Contains(item))
                            coinList.Remove(item);
                }

            foreach (var list in popsInRacks)
                foreach (var item in list)
                {
                    foreach (var popList in remaining.PopCansInPopCanRacks)
                        if (popList.Contains(item))
                            popList.Remove(item);
                }

            foreach (var item in coinsInStorage)
            {
                if (remaining.PaymentCoinsInStorageBin.Contains(item))
                    remaining.PaymentCoinsInStorageBin.Remove(item);
            }


            return remaining;
        }

    }
}
